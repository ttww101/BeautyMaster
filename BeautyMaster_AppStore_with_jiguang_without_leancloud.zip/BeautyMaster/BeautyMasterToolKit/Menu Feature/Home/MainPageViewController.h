
#import <UIKit/UIKit.h>
#import "BsViewController.h"

@interface MainPageViewController : BsViewController

@end
