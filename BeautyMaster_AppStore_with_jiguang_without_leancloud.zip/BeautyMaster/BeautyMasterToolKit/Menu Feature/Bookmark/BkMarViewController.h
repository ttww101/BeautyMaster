#import <UIKit/UIKit.h>

@interface BkMarViewController : UITableViewController

@end
