#import <UIKit/UIKit.h>

@interface InfoDetailViewController :UIViewController

- (id)initWithIndex:(NSString *)__index;

@end
