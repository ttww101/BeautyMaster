#import <UIKit/UIKit.h>

@interface MenuListViewController : UITableViewController

-(id)initWithURL:(NSString *)__url AndName:(NSString *)__name;

@end
