#import <UIKit/UIKit.h>

@interface DetailViewController :UIViewController

- (id)initWithIndex:(NSString *)__index;

@end