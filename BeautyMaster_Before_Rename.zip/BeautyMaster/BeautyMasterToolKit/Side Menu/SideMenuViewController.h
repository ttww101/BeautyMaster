//
//  SideMenuViewController.h
//  iYeHua
//
//  Created by Apple on 13-5-21.
//  Copyright (c) 2013年 App4life Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SideMenuViewController : UIViewController


@end
