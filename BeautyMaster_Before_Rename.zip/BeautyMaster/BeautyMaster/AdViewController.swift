//
//  AdViewController.swift
//  BeautyMaster
//
//  Created by Apple on 2019/3/23.
//  Copyright © 2019 whitelok.com. All rights reserved.
//

import UIKit
import WebKit

class AdViewController: UIViewController {
    
    @IBOutlet weak var closeBtn: UIButton!
    @IBOutlet weak var wkWebView: WKWebView!
    let outlookEmail:String = "leancloud201901@outlook.com"
    let folderName:String = "master.beauty.me"

    override func viewDidLoad() {
        super.viewDidLoad()

        let adUrl = "https://drv.tw/~"+outlookEmail+"/od/"+folderName+"/ad.html"
        if let url:URL = URL(string: adUrl) {
            
            let request:URLRequest = URLRequest(url: url)
            self.wkWebView.load(request)
            
        }
        
        closeBtn.layer.cornerRadius = 10
        closeBtn.clipsToBounds = true
        closeBtn.addTargetClosure { (sender) in
            self.dismiss(animated: true, completion: nil)
        }
        
    }

}
